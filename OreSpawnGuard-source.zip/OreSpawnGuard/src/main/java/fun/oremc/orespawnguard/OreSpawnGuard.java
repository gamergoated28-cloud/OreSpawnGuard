package fun.oremc.orespawnguard;

import com.sk89q.worldedit.bukkit.BukkitAdapter;
import com.sk89q.worldguard.WorldGuard;
import com.sk89q.worldguard.protection.regions.ApplicableRegionSet;
import com.sk89q.worldguard.protection.regions.ProtectedRegion;
import com.sk89q.worldguard.protection.regions.RegionQuery;
import org.bukkit.Location;
import org.bukkit.block.Block;
import org.bukkit.entity.Entity;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBurnEvent;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.block.BlockFromToEvent;
import org.bukkit.event.block.BlockIgniteEvent;
import org.bukkit.event.block.BlockPistonExtendEvent;
import org.bukkit.event.block.BlockPistonRetractEvent;
import org.bukkit.event.block.BlockSpreadEvent;
import org.bukkit.event.entity.EntityChangeBlockEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Iterator;

public final class OreSpawnGuard extends JavaPlugin implements Listener {
    private RegionQuery regionQuery;

    @Override
    public void onEnable() {
        if (!getServer().getPluginManager().isPluginEnabled("WorldGuard")) {
            getLogger().severe("WorldGuard is required. Disabling OreSpawnGuard.");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }
        regionQuery = WorldGuard.getInstance().getPlatform().getRegionContainer().createQuery();
        getServer().getPluginManager().registerEvents(this, this);
        getLogger().info("Enabled. Environmental block damage is blocked inside named WorldGuard regions in every world.");
    }

    /** Returns true inside any named WorldGuard region. The global region is deliberately ignored. */
    private boolean isProtected(Location location) {
        if (location == null || location.getWorld() == null) return false;
        ApplicableRegionSet regions = regionQuery.getApplicableRegions(BukkitAdapter.asBlockVector(location));
        for (ProtectedRegion region : regions) {
            if (!"__global__".equalsIgnoreCase(region.getId())) return true;
        }
        return false;
    }

    private void filterExplosionBlocks(Iterator<Block> blocks) {
        while (blocks.hasNext()) {
            if (isProtected(blocks.next().getLocation())) blocks.remove();
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onEntityExplosion(EntityExplodeEvent event) {
        filterExplosionBlocks(event.blockList().iterator());
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onBlockExplosion(BlockExplodeEvent event) {
        filterExplosionBlocks(event.blockList().iterator());
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onBurn(BlockBurnEvent event) {
        if (isProtected(event.getBlock().getLocation())) event.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onIgnite(BlockIgniteEvent event) {
        if (isProtected(event.getBlock().getLocation())) event.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onEntityChangeBlock(EntityChangeBlockEvent event) {
        if (isProtected(event.getBlock().getLocation())) event.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onSpread(BlockSpreadEvent event) {
        if (isProtected(event.getBlock().getLocation())) event.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onFluidFlow(BlockFromToEvent event) {
        if (isProtected(event.getToBlock().getLocation())) event.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onPistonExtend(BlockPistonExtendEvent event) {
        if (pistonTouchesProtected(event.getBlocks(), event.getDirection().getDirection())) event.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onPistonRetract(BlockPistonRetractEvent event) {
        if (pistonTouchesProtected(event.getBlocks(), event.getDirection().getDirection())) event.setCancelled(true);
    }

    private boolean pistonTouchesProtected(Iterable<Block> movedBlocks, org.bukkit.util.Vector direction) {
        for (Block block : movedBlocks) {
            if (isProtected(block.getLocation()) || isProtected(block.getLocation().add(direction))) return true;
        }
        return false;
    }
}
