OreSpawnGuard 1.0.0 - SOURCE PROJECT

What it does:
- Uses WorldGuard regions in every world; no world names or radius settings are needed.
- Protects blocks inside any named WorldGuard region from Bukkit explosion block damage (entity and block explosions).
- Also blocks burn/ignite, entity block changes, block spread, fluid flow into protected regions, and piston movement touching protected regions.
- Does NOT cancel normal player BlockBreakEvent or BlockPlaceEvent. WorldGuard remains responsible for normal player permissions.
- Ignores the WorldGuard __global__ region so the whole world is not accidentally protected.

Requirements:
- Paper 1.21.11 (or compatible Paper build)
- Java 21+ runtime
- WorldGuard 7.0.14 installed

Build:
- Build this project with Maven: mvn clean package
- Output: target/OreSpawnGuard-1.0.0.jar
- Put that JAR in plugins/ and restart the server.

IMPORTANT LIMITATION:
Some plugins (including some tornado/fruit abilities) may change blocks directly through internal APIs or WorldEdit/FastAsyncWorldEdit without firing Bukkit events. This plugin cannot intercept every such direct modification. If Cyclone still changes blocks inside a WorldGuard region, the MagicalFruits ability must be configured/modified to respect WorldGuard or its own block-change logic must be patched. Test on a backup/test server first.

PHONE-ONLY BUILD OPTION (GitHub Actions):
1. Create a new GitHub repository.
2. Upload the contents of this source ZIP into the repository (not the ZIP file itself).
3. Open the repository's Actions tab and run "Build OreSpawnGuard" (or wait for the push build).
4. When it succeeds, open the completed workflow run and download the OreSpawnGuard-1.0.0 artifact.
5. Extract the downloaded artifact ZIP; inside is OreSpawnGuard-1.0.0.jar.
6. Upload that JAR to the server plugins folder and restart.
Do not upload this source ZIP itself as a plugin. It is a source project, not the finished plugin JAR.
